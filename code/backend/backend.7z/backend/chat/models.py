#DB연동1차_chat/models.py 파일 추가
from django.db import models

# 1. 운영 데이터: 사용자 대화 기록 저장
class ChatHistory(models.Model):
    user_session_id = models.CharField(max_length=255, verbose_name="사용자 세션 ID")
    question = models.TextField(verbose_name="사용자 질문")
    answer = models.TextField(verbose_name="챗봇 답변")
    timestamp = models.DateTimeField(auto_now_add=True, verbose_name="기록 시각")
    
    def __str__(self):
        return f"{self.user_session_id}: {self.question[:30]}"

# 2. 학습/검색 데이터: 크롤링 원본 데이터 저장 (RAG 시스템의 지식 원천)
class SourceDocument(models.Model):
    title = models.CharField(max_length=500, verbose_name="문서 제목")
    content = models.TextField(verbose_name="문서 본문")
    source_url = models.URLField(max_length=2000, verbose_name="출처 URL", blank=True, null=True)
    added_date = models.DateTimeField(auto_now_add=True, verbose_name="추가일")
    
    def __str__(self):
        return self.title