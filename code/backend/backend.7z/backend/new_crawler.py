#DB연동1차_크롤링
# new_crawler_colab.py (Colab/Jupyter용 코드)

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options as ChromeOptions # Chrome Options 임포트
from webdriver_manager.chrome import ChromeDriverManager
from bs4 import BeautifulSoup
import time
import pandas as pd # Colab에서는 DB 대신 DataFrame에 저장 후 다운로드

# new_crawler_colab.py (크롤링 함수 및 실행 부분)

# --- 1. DB 저장을 대체할 리스트 정의 ---
crawled_data = []

def scrape_law_articles_colab(url):
    """
    Colab 환경에서 헤드리스 Chrome을 사용하여 법령을 크롤링합니다.
    (강제 time.sleep을 추가하여 내부 충돌을 회피합니다.)
    """
    global crawled_data
    
    # 드라이버는 함수 내에서만 유지되도록 합니다.
    driver = None
    
    try:
        # 1-1. 드라이버 자동 설정 및 실행 (Chrome 기반)
        service = Service(ChromeDriverManager().install())
        options = ChromeOptions()
        
        # Colab/서버 환경 실행을 위한 필수 옵션 (Headless)
        options.add_argument('--headless') 
        options.add_argument('--no-sandbox') 
        options.add_argument('--disable-dev-shm-usage')
        options.add_argument('--disable-gpu')
        
        driver = webdriver.Chrome(service=service, options=options)
        driver.get(url)
        
        print(f"✅ 접속 성공: {url} (헤드리스 모드)")
        
        # 1-2. 페이지 로딩 대기 (15초 대기 후 강제 5초 대기)
        # body 태그 로드 확인 후, 강제 time.sleep으로 내부 충돌 회피
        WebDriverWait(driver, 15).until( 
            EC.presence_of_element_located((By.TAG_NAME, 'body'))
        )
        # 🚨 강제 지연 추가: 봇 차단을 우회하고 DOM 로딩을 확실히 기다립니다.
        time.sleep(5) 
        
        print("페이지 요소 로딩 완료 확인.")
        
        # 1-3. 로딩된 최종 HTML 추출
        soup = BeautifulSoup(driver.page_source, 'html.parser')
        
        # --- 2. 데이터 추출 로직 ---
        
        law_title_element = soup.select_one('#lawNm, .h_law_v2') 
        if not law_title_element:
            print(f"❌ 오류: {url}에서 법률 제목을 찾을 수 없습니다. (HTML 재확인 필요)")
            return

        law_title = law_title_element.text.split('(')[0].strip()
        article_containers = soup.find_all('section', class_='jo_cont')
        
        if not article_containers:
            print(f"❌ 오류: {url}에서 조항 컨테이너(section.jo_cont)를 찾을 수 없습니다.")
            return

        count = 0
        for container in article_containers:
            # 2-3. 조항 제목 추출 (h4.jo_title)
            article_title_element = container.find('h4', class_='jo_title') 
            if not article_title_element: continue 
            
            article_title = article_title_element.text.strip()
            final_title = f"{law_title} {article_title}"
            
            # 2-4. 조항 내용 추출 (text_area)
            content_element = container.find('div', class_='text_area')
            if not content_element: continue

            content = content_element.text.strip()
            
            # 3. 데이터 리스트에 저장
            crawled_data.append({
                'title': final_title,
                'content': content,
                'source_url': url + "#" + article_title.split('(')[0]
            })
            # print(f"✅ 수집 성공: {final_title}") # 성공 메시지는 너무 많으므로 생략
            count += 1

        print(f"--- {law_title}에서 총 {count}개 조항 수집 완료 ---")

    except Exception as e:
        print(f"❌ Selenium/크롤링 중 알 수 없는 오류 ({url}): {e}")
    finally:
        if driver:
            driver.quit() # 항상 브라우저를 닫도록 보장

if __name__ == "__main__":
    
    target_urls = [
        "https://www.law.go.kr/법령/전자서명법",
    ]

    print(f"\n--- RAG 지식 크롤링 시작 (Colab/Jupyter): 총 {len(target_urls)}개 법률 크롤링 ---")
    
    for url in target_urls:
        scrape_law_articles_colab(url)
        time.sleep(2)
        
    print("\n--- RAG 지식 크롤링 및 수집 완료 ---")
    
    # 4. 데이터프레임으로 변환 및 출력
    if crawled_data:
        df = pd.DataFrame(crawled_data)
        print("\n--- 수집된 최종 데이터 (상위 5개) ---")
        print(df.head())
        
        # 5. 파일을 로컬 PC로 다운로드 가능
        # df.to_csv('전자서명법_조항.csv', index=False, encoding='utf-8-sig')
        # print("데이터가 '전자서명법_조항.csv' 파일로 저장되었습니다.")
    else:
        print("수집된 데이터가 없습니다.")