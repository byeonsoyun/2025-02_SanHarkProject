import psycopg2
import os
import json
from dotenv import load_dotenv
from sentence_transformers import SentenceTransformer
import numpy as np

# ----------------------------------------------------------------------
# 🔑 DB 설정 (index_data.py와 동일하게 환경변수를 로드합니다.)
# ----------------------------------------------------------------------
load_dotenv() 

DB_CONFIG = {
    "host": os.getenv("DB_HOST", "localhost"),
    "database": os.getenv("DB_NAME", "law_db"),
    "user": os.getenv("DB_USER", "law_user"),
    "password": os.getenv("DB_PASSWORD", "1111"),
    "port": os.getenv("DB_PORT", "5432")
}

# ----------------------------------------------------------------------
# 🔎 pgvector 검색 함수
# ----------------------------------------------------------------------

def search_pgvector(query: str, k: int = 5):
    """
    사용자 쿼리를 임베딩하고, pgvector를 사용하여 DB에서 유사한 청크를 검색합니다.
    """
    # 1. 임베딩 모델 로드 및 쿼리 벡터 생성 (인덱싱에 사용한 것과 동일해야 함)
    embedding_model = SentenceTransformer("jhgan/ko-sroberta-multitask") 
    query_embedding = embedding_model.encode([query])[0]
    
    # numpy array를 pgvector SQL 쿼리에 사용 가능한 문자열 형태로 변환
    query_vector_str = "[" + ",".join(map(str, query_embedding)) + "]"
    
    conn = None
    results = []

    try:
        conn = psycopg2.connect(**DB_CONFIG)
        cur = conn.cursor()
        
        # 2. pgvector 유사도 검색 쿼리 실행 (L2 distance 사용)
        cur.execute(
            f"""
            SELECT 
                text_chunk, 
                metadata,
                embedding <-> '{query_vector_str}' AS distance
            FROM rag_index_table
            ORDER BY distance
            LIMIT {k}
            """
        )
        
        # 3. 결과 정리
        for row in cur.fetchall():
            text_chunk, metadata_json, distance = row
            
            results.append({
                "chunk": text_chunk,
                "metadata": metadata_json,
                "distance": distance
            })
            
        cur.close()
        
    except (Exception, psycopg2.Error) as error:
        print(f"pgvector 검색 중 오류 발생: {error}")
        
    finally:
        if conn:
            conn.close()
            
    return results

# ----------------------------------------------------------------------
# 🧪 테스트 코드 
# ----------------------------------------------------------------------
if __name__ == "__main__":
    test_query = "상속세의 납부 기한은 어떻게 되나요?"
    print(f"테스트 쿼리: {test_query}")
    
    search_results = search_pgvector(test_query, k=3)
    
    if search_results:
        print(f"\n✅ 검색 성공: 총 {len(search_results)}개 결과 확인")
        for i, result in enumerate(search_results):
            print(f"--- 결과 {i+1} (거리: {result['distance']:.4f}) ---")
            chunk_preview = result['chunk'][:100].replace('\n', ' ') 
            print(f"청크 내용: {chunk_preview}...")
            
            metadata = result['metadata']
            if isinstance(metadata, dict):
                 print(f"메타데이터 (제목): {metadata.get('title', 'N/A')}")
            else:
                 print(f"메타데이터 (원본): {metadata}")

    else:
        print("\n❌ 검색 실패: 결과를 찾을 수 없습니다. DB 연결 및 인덱스를 확인해 주세요.")