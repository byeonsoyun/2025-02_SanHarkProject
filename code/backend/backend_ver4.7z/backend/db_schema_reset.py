import psycopg2
import os
import sys
from dotenv import load_dotenv

# DataProcessor 클래스에서 차원 정보를 가져오기 위해 경로 추가
sys.path.append(os.path.dirname(os.path.abspath(__file__)) + '/chat')
from data_processor import DataProcessor 

load_dotenv()

DB_CONFIG = {
    "host": os.getenv("DB_HOST", "localhost"),
    "database": os.getenv("DB_NAME", "law_db"),
    "user": os.getenv("DB_USER", "law_user"),
    "password": os.getenv("DB_PASSWORD", "1111"),
    "port": os.getenv("DB_PORT", "5432")
}

def reset_rag_table_schema(db_config):
    """
    기존 rag_index_table을 삭제하고, 새로운 768차원 벡터 타입으로 
    테이블을 강제로 다시 생성합니다.
    """
    conn = None
    try:
        conn = psycopg2.connect(**db_config)
        cur = conn.cursor()
        
        # 1. 기존 테이블 강제 삭제 (DROP)
        cur.execute("DROP TABLE IF EXISTS rag_index_table;")
        print("✅ 기존 rag_index_table 테이블 정의가 삭제되었습니다.")
        
        # 2. pgvector 확장(Extension) 존재 확인
        cur.execute("CREATE EXTENSION IF NOT EXISTS vector;")

        # 3. 새로운 768차원 테이블 강제 생성 (CREATE)
        cur.execute(f"""
            CREATE TABLE public.rag_index_table (
                id SERIAL PRIMARY KEY,
                text_chunk TEXT NOT NULL,
                metadata JSONB,
                -- DataProcessor의 VECTOR_DIMENSION(768)을 사용
                embedding VECTOR({DataProcessor.VECTOR_DIMENSION})
            );
        """)
        
        conn.commit()
        print(f"✅ rag_index_table이 {DataProcessor.VECTOR_DIMENSION}차원 벡터 타입으로 새로 생성되었습니다. (인덱싱 준비 완료)")

    except (Exception, psycopg2.Error) as error:
        print(f"데이터베이스 스키마 재설정 중 심각한 오류 발생: {error}")
        if conn:
            conn.rollback() 
            raise

    finally:
        if conn:
            cur.close()
            conn.close()

if __name__ == "__main__":
    reset_rag_table_schema(DB_CONFIG)