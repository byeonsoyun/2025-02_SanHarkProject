# backend/chat/management/commands/import_precedents.py

import pandas as pd
import os
from django.core.management.base import BaseCommand
from django.conf import settings
from chat.models import LawDocument
from datetime import datetime

class Command(BaseCommand):
    help = '수집된 CSV 파일에서 판례 데이터를 읽어 LawDocument DB에 Upsert합니다.'

    def handle(self, *args, **options):
        # BASE_DIR을 프로젝트 루트 (backend)로 설정
        base_dir = settings.BASE_DIR 
        
        # 파일 경로 설정 (backend/data 폴더에 있다고 가정, 현재 파일이 있는 위치 기준 조정 필요)
        # 현재는 manage.py와 같은 레벨에 '공무원_판례_6948개.csv'가 있으므로, settings.py에 'data' 폴더 경로를 추가하거나 
        # 임시로 현재 디렉토리 경로를 사용해야 합니다.
        
        # 임시 조치: manage.py와 같은 위치에서 파일을 찾도록 설정합니다.
        file_path = os.path.join(base_dir, '공무원_판례_6948개.csv')
        
        if not os.path.exists(file_path):
            self.stderr.write(self.style.ERROR(f"❌ 파일 경로를 찾을 수 없습니다: {file_path}. 파일 위치를 확인하세요."))
            return

        self.stdout.write(self.style.NOTICE(f"🔍 '{file_path}' 파일에서 데이터 로드 시작..."))
        
        try:
            df = pd.read_csv(file_path, encoding='utf-8-sig')
            self.stdout.write(self.style.SUCCESS(f"✅ 총 {len(df)}개의 판례 데이터를 로드했습니다."))
            
            new_documents = []
            
            # 기존 DB의 판례일련번호 목록을 가져와 중복 확인
            existing_ids = set(LawDocument.objects.filter(doc_type='PRECEDENT').values_list('document_id', flat=True))
            
            for index, row in df.iterrows():
                doc_id = str(row['판례일련번호'])
                
                if doc_id in existing_ids:
                    continue

                new_documents.append(
                    LawDocument(
                        document_id=doc_id,
                        doc_type='PRECEDENT',
                        title=row['사건명'],
                        content=f"사건명: {row['사건명']}, 사건번호: {row['사건번호']}, 법원명: {row['법원명']}", 
                        source_url=row['판례상세링크'],
                        enforcement_date=str(row['선고일자']),
                        case_number=row['사건번호'],
                        court_name=row['법원명'],
                    )
                )

            if new_documents:
                # bulk_create를 사용하며, primary key 충돌을 무시하도록 설정 (Django 2.2+ 필요)
                # 이 경우, 위에 existing_ids 필터링을 했기 때문에 ignore_conflicts는 필요 없으나, 안전을 위해 남겨둡니다.
                created_count = LawDocument.objects.bulk_create(new_documents) 
                self.stdout.write(self.style.SUCCESS(f'✨ 성공! {len(created_count)}개의 새로운 판례 데이터를 DB에 주입했습니다.'))
            else:
                self.stdout.write(self.style.WARNING('데이터베이스에 새로운 판례가 없습니다. 삽입 건너뛰기.'))

        except Exception as e:
            self.stderr.write(self.style.ERROR(f"❌ 데이터 주입 중 오류 발생: {e}"))