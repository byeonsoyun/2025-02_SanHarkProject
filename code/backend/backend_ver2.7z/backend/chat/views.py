import os
import json
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.conf import settings

#DB연동1차추가_models.py import
from user_mgmt.models import ChatHistory, UploadedDocument # UploadedDocument 추가
# Import RAG integration
try:
    from .rag_integration import rag_chatbot
    RAG_AVAILABLE = True
except ImportError:
    RAG_AVAILABLE = False
    print("RAG integration not available. Using fallback responses.")

@csrf_exempt
def chat_message(request):
    """Handle chat messages with RAG integration"""
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            message = data.get("message", "")
            # (핵심 수정 부분) 세션 ID를 JSON 데이터에서 가져옵니다.
            session_id = data.get("user_session_id", "ANONYMOUS") # 기본값 설정
            if not message.strip():
                return JsonResponse({"error": "Empty message"}, status=400)
            
            # Use RAG system if available
            if RAG_AVAILABLE:
                reply = rag_chatbot.chat(message)
            else:
                # Fallback response
                reply = f"Echo: {message} (RAG system not available)"
            print(f"--- [디버그] RAG 응답: {reply[:20]}...") # <--- 디버그 포인트 1
                
            try: # <--- try-except로 로그 저장을 감싸서 예외를 포착해야 합니다.
                # DB연동1차추가_ 핵심 작업: 대화 로그 저장 로직 삽입
                ChatHistory.objects.create(
                    user_session_id=session_id, 
                    question=message,
                    answer=reply
                )
                print("--- [디버그] ChatHistory 저장 성공 시도 ---") # <--- 디버그 포인트 2
            except Exception as db_e:
                print(f"--- [에러] ChatHistory 저장 실패: {db_e} ---") # <--- 디버그 포인트 3
                
            return JsonResponse({"reply": reply})
            
        except json.JSONDecodeError:
            return JsonResponse({"error": "Invalid JSON"}, status=400)
        except Exception as e:
            return JsonResponse({"error": str(e)}, status=500)
    
    return JsonResponse({"error": "POST 요청만 가능"}, status=400)

@csrf_exempt
def upload_pdf(request):
    """Handle PDF upload and processing with RAG"""
    if request.method == "POST" and request.FILES.get("pdf"):
        try:
            pdf_file = request.FILES["pdf"]
            session_id = request.POST.get('user_session_id', 'ANONYMOUS') # 세션 ID 추출
            # Validate file type
            if not pdf_file.name.lower().endswith('.pdf'):
                return JsonResponse({"error": "PDF 파일만 업로드 가능합니다."}, status=400)
            
            # 1. DB에 UploadedDocument 레코드 생성 (파일 시스템 저장 포함)
            doc_instance = UploadedDocument.objects.create(
                user_session_id=session_id,
                file=pdf_file, # FileField에 직접 파일 객체 전달
                filename=pdf_file.name
                # is_rag_ready = False (default)
            )

            # 2. 비동기 텍스트 추출 및 RAG 처리는 여기에 위치 (현재는 RAG_AVAILABLE 확인으로 대체)
            if RAG_AVAILABLE:
                # rag_chatbot.process_pdf(doc_instance.file.path) 대신 
                # 비동기적으로 텍스트 추출 및 임베딩 로직을 호출해야 함 (Celery 추천)
                reply = f"PDF 업로드 완료 및 DB 등록됨: {pdf_file.name}"
            else:
                reply = f"PDF 업로드 완료 및 DB 등록됨: {pdf_file.name} (RAG 처리 불가)"

            return JsonResponse({"reply": reply})
            
        except Exception as e:
            return JsonResponse({"error": f"PDF 처리 중 오류: {str(e)}"}, status=500)

    return JsonResponse({"error": "PDF 파일이 없거나 요청 방식이 잘못되었습니다."}, status=400)
@csrf_exempt
def upload_json_csv(request):
    """Handle JSON/CSV upload for RAG system"""
    if request.method == "POST" and request.FILES.get("file"):
        try:
            uploaded_file = request.FILES["file"]
            
            # Validate file type
            if not (uploaded_file.name.lower().endswith('.json') or 
                   uploaded_file.name.lower().endswith('.csv')):
                return JsonResponse({"error": "JSON 또는 CSV 파일만 업로드 가능합니다."}, status=400)
            
            # Save file
            save_dir = os.path.join(settings.MEDIA_ROOT, "uploaded_data")
            os.makedirs(save_dir, exist_ok=True)
            file_path = os.path.join(save_dir, uploaded_file.name)

            with open(file_path, "wb+") as f:
                for chunk in uploaded_file.chunks():
                    f.write(chunk)

            # Process with RAG system if available
            if RAG_AVAILABLE:
                try:
                    # Load and process data
                    text_data = rag_chatbot.processor.load_data(file_path)
                    chunks = rag_chatbot.processor.chunk_text(text_data)
                    
                    if not rag_chatbot.is_initialized:
                        rag_chatbot.processor.create_embeddings(chunks)
                        rag_chatbot.processor.create_faiss_index()
                    else:
                        # Add to existing index
                        new_embeddings = rag_chatbot.processor.embedding_model.encode(chunks)
                        rag_chatbot.processor.chunks.extend(chunks)
                        rag_chatbot.processor.index.add(new_embeddings.astype('float32'))
                    
                    # Save updated index
                    rag_chatbot.processor.save_index()
                    rag_chatbot.is_initialized = True
                    
                    reply = f"데이터 파일 처리 완료: {uploaded_file.name}\n{len(chunks)}개 청크가 지식베이스에 추가되었습니다."
                except Exception as e:
                    reply = f"데이터 파일 업로드 완료: {uploaded_file.name}\n처리 중 오류: {str(e)}"
            else:
                reply = f"데이터 파일 업로드 완료: {uploaded_file.name} (RAG 처리 불가)"

            return JsonResponse({"reply": reply})
            
        except Exception as e:
            return JsonResponse({"error": f"파일 처리 중 오류: {str(e)}"}, status=500)

    return JsonResponse({"error": "파일이 없습니다."}, status=400)
