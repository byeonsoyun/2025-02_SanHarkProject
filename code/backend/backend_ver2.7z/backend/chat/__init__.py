# chat/__init__.py
#DB연동1차_chat/apps.py에 대해 실행하려면 명시적으로 이 파일이 필요하다네요
# 우리가 만들 ChatConfig를 이 앱의 기본 설정으로 지정합니다.
default_app_config = 'chat.apps.ChatConfig'