import React from "react";
import { Container, Row, Col, Card } from "react-bootstrap";
// import { FaScale, FaLightbulb, FaRobot } from 'react-icons/fa'; // 외부 라이브러리 대신 유니코드 이모지 사용

const About = () => {
    const textColor = 'var(--text-color)';
    const dimTextColor = 'var(--dim-text-color)';
    const cardBg = 'var(--bg-card)';
    const primaryColor = 'var(--primary-color)';
    const sectionSpacing = '4rem'; // Home 페이지와 동일한 간격 변수 사용

    // 아이콘 대신 이모지 스타일 (사용하지 않음. 이모지 자체 스타일링으로 대체)
    // const iconStyle = { fontSize: '2.5rem', marginBottom: '1rem', display: 'block' };

    // 핵심 가치 데이터
    const coreValues = [
        { title: "공정성 (Fairness)", text: "편향되지 않고 객관적인 데이터를 기반으로, 모두에게 동등한 법률 정보 접근 기회를 제공합니다.", emoji: "⚖️" },
        { title: "혁신 (Innovation)", text: "최신 AI 기술을 활용하여 기존의 복잡하고 비용이 많이 드는 법률 자문 과정을 혁신합니다.", emoji: "💡" },
        { title: "접근성 (Accessibility)", text: "시간과 장소의 제약 없이, 누구나 스마트폰이나 PC로 쉽게 법률 정보를 얻을 수 있도록 합니다.", emoji: "🌐" },
    ];

    // 개발팀 데이터 (GitHub 링크 반영됨)
    const teamMembers = [
        {
            name: "변소윤",
            position: "백엔드/DB 엔지니어",
            skills: "Node.js, PostgreDB, AWS, Django",
            linkText: "GitHub 링크",
            linkUrl: "https://github.com/byeonsoyun/2025-02_SanHarkProject.git",
            emoji: "👨‍💻"
        },
        {
            name: "양현아",
            position: "프론트엔드 개발자",
            skills: "React, Bootstrap, Tailwind CSS",
            linkText: "GitHub 링크",
            linkUrl: "https://github.com/byeonsoyun/2025-02_SanHarkProject.git",
            emoji: "👩‍💻"
        },
        {
            name: "박상수",
            position: "AI/ML 엔지니어",
            skills: "Python, TensorFlow, PyTorch, Open API(국가법령정보센터)",
            linkText: "GitHub 링크",
            linkUrl: "https://github.com/byeonsoyun/2025-02_SanHarkProject.git",
            emoji: "🤖"
        }
    ];

    return (
        <div style={{
            backgroundColor: 'var(--bg-main)',
            color: textColor,
            paddingBottom: '50px'
        }}>
            <Container className="py-5" style={{ marginBottom: sectionSpacing }}>
                <div className="text-center">
                    <h1 className="display-4 fw-bold mb-3" style={{ color: primaryColor }}>
                        LawFriend: 법률의 미래를 개척하다
                    </h1>
                    <p className="lead" style={{ color: dimTextColor }}>
                        모두가 쉽고 빠르게 법률 자문에 접근할 수 있는 세상을 만듭니다.
                    </p>
                </div>
            </Container>

            {/* 1. 핵심 가치 섹션 (Core Values) - 리디자인된 섹션 */}
            <Container style={{ marginBottom: sectionSpacing }}>
                <h2 className="text-center mb-5 fw-bolder">우리의 핵심 가치</h2>
                <Row xs={1} md={3} className="g-4">
                    {coreValues.map((value, index) => (
                        <Col key={index}>
                            <div
                                className="p-4 h-100 rounded-lg shadow-md"
                                style={{
                                    backgroundColor: cardBg,
                                    borderLeft: `5px solid ${primaryColor}`, // 왼쪽 강조 테두리
                                    borderRadius: '8px',
                                    transition: 'all 0.3s ease-in-out',
                                    // 호버 효과 추가 (인라인 스타일은 한계가 있어 CSS 클래스/인라인 핸들러가 필요하지만, 여기서는 기본적인 클린 디자인에 집중)
                                }}
                            >
                                {/* Icon/Emoji */}
                                <div 
                                    role="img" 
                                    aria-label={value.title} 
                                    style={{ 
                                        fontSize: '2.5rem', 
                                        marginBottom: '1rem', 
                                        color: primaryColor,
                                        display: 'inline-block',
                                        // 아이콘 주변에 원형 배경 효과 추가
                                        backgroundColor: `${primaryColor}15`, // primaryColor의 투명도 15%
                                        borderRadius: '50%',
                                        padding: '10px 15px',
                                    }}
                                >
                                    {value.emoji}
                                </div>
                                
                                {/* Title */}
                                <h3 className="fw-bold mb-3" style={{ color: textColor, fontSize: '1.4rem' }}>
                                    {value.title}
                                </h3>
                                
                                {/* Text */}
                                <p style={{ color: dimTextColor, lineHeight: '1.6' }}>
                                    {value.text}
                                </p>
                            </div>
                        </Col>
                    ))}
                </Row>
            </Container>

            {/* 2. 기술 및 경고 섹션 (Technology & Disclaimer) */}
            <Container 
                className="p-4" 
                style={{ 
                    backgroundColor: cardBg, 
                    borderRadius: '10px', 
                    boxShadow: '0 4px 12px rgba(0,0,0,0.05)', 
                    marginBottom: sectionSpacing 
                }}
            >
                <Row className="align-items-center">
                    <Col md={7}>
                        <h3 className="fw-bold mb-3" style={{ color: primaryColor }}>기술적 배경</h3>
                        <p style={{ color: textColor }}>
                            LawFriend는 Google의 강력한 **Gemini API**를 기반으로 구동됩니다. 특히 방대한 양의 민사법 관련 판례, 법령 및 학술 자료를 학습하여 법률 자문에 최적화된 응답을 제공합니다.
                        </p>
                    </Col>
                    <Col md={5}>
                        <h3 className="fw-bold mb-3" style={{ color: 'red' }}>중요 고지</h3>
                        <p className="small" style={{ color: dimTextColor, borderLeft: `3px solid red`, paddingLeft: '10px' }}>
                            **LawFriend는 법률 자문 챗봇 서비스일 뿐, 정식 변호사의 법률적 조언이나 대리 행위를 제공하지 않습니다.** 챗봇의 답변은 참고용으로만 사용해야 하며, 중요한 법적 결정은 반드시 전문 변호사와 상의하시기 바랍니다.
                        </p>
                    </Col>
                </Row>
            </Container>

            {/* 3. 개발팀 정보 섹션 (Team Information) */}
            <Container style={{ marginBottom: sectionSpacing }}>
                <h2 className="text-center mb-5 fw-bolder">개발팀 소개</h2>
                <Row xs={1} md={3} className="g-4">
                    {teamMembers.map((member, index) => (
                        <Col key={index}>
                            <Card className="text-center h-100 p-4" style={{ backgroundColor: cardBg, color: textColor, transition: 'all 0.3s' }}>
                                <Card.Body>
                                    <div style={{ fontSize: '3rem', marginBottom: '1rem' }} role="img" aria-label="Developer Emoji">{member.emoji}</div>
                                    <Card.Title className="fw-bold mb-1" style={{ fontSize: '1.5rem' }}>{member.name}</Card.Title>
                                    <Card.Subtitle className="mb-2" style={{ color: primaryColor, fontWeight: '600' }}>{member.position}</Card.Subtitle>
                                    <hr style={{ borderColor: 'var(--border-color)', margin: '10px auto' }}/>
                                    <Card.Text style={{ color: dimTextColor, fontSize: '0.9em' }}>
                                        <span className="fw-bold">주요 기술:</span> {member.skills}
                                    </Card.Text>
                                    <p style={{ marginTop: '10px' }}>
                                        <a href={member.linkUrl} target="_blank" rel="noopener noreferrer" className="text-decoration-underline" style={{ color: primaryColor }}>{member.linkText}</a>
                                    </p>
                                </Card.Body>
                            </Card>
                        </Col>
                    ))}
                </Row>
            </Container>

        </div>
    );
};

export default About;