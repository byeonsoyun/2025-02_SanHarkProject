import React from "react";
// Link는 Navbar에서 사용하므로 여기서는 필요 없지만, 부트스트랩 컴포넌트는 유지합니다.
import { Container, Row, Col, Card } from "react-bootstrap";

// 이 컴포넌트는 App.js에서 'Home' 컴포넌트로 사용될 것입니다.
const Home = () => {
    // 테마 변수 사용
    const textColor = 'var(--text-color)';
    const dimTextColor = 'var(--dim-text-color)';
    const cardBg = 'var(--bg-card)';
    const borderColor = 'var(--border-color)';
    const primaryColor = 'var(--primary-color)';

    // --- [조정 가능한 변수]: 섹션 간의 수직 간격 (Margin Top/Bottom) ---
    // 이 값을 조정하여 섹션 간의 거리를 쉽게 바꿀 수 있습니다. (예: '5rem', '3rem', '100px')
    const sectionSpacing = '10rem'; 
    const normalSpacing = '5rem';

    
    return (
        <div style={{
            backgroundColor: 'var(--bg-main)',
            color: textColor,
            transition: 'background-color 0.3s, color 0.3s',
            paddingBottom: '30px' // 하단 푸터와의 공간 확보
        }}>
           {/* 1. Hero 섹션: 서비스의 핵심 메시지 */}
           <Container 
                className="text-center py-5" 
                style={{
                    borderBottom: `1px solid ${borderColor}`,
                    // mb-5 대신 변수 적용
                    marginBottom: sectionSpacing, 
                    marginTop: normalSpacing 
                }}
            >
                <h1 className="display-4 fw-bold" style={{ color: primaryColor, transition: 'color 0.3s' }}>
                    LawFriend, AI 법률 자문 챗봇
                </h1>
                <p className="lead mt-4" style={{ color: dimTextColor, transition: 'color 0.3s' }}>
                    새로운 차원의 대화를 경험하세요. 질문하고, 배우고, 창조하세요.
                </p>
            </Container>

            {/* 2. 기능 소개 섹션: 카드 레이아웃 사용 */}
            <Container 
                // mb-5 대신 변수 적용
                style={{ marginBottom: sectionSpacing }}
            >
                <h2 className="text-center mb-4 fw-bolder" style={{ color: textColor }}>주요 기능</h2>
                {/* 카드 간 간격(Gutter)은 g-4 유지 */}
                <Row xs={1} md={3} className="g-4">
                    {/* 카드 1: 대화 기록 관리 */}
                    <Col>
                        <Card style={{ backgroundColor: cardBg, color: textColor, borderColor: borderColor, transition: 'all 0.3s' }}>
                            <Card.Body>
                            <Card.Title style={{ color: primaryColor }}>대화 기록 관리</Card.Title>
                            <Card.Text style={{ color: dimTextColor }}>
                                옆 사이드바에서 이전 대화를 쉽게 확인하고, 새로운 세션을 시작할 수 있습니다.
                            </Card.Text>
                            </Card.Body>
                        </Card>
                    </Col>

                    {/* 카드 2: 다크 모드 */}
                    <Col>
                        <Card style={{ backgroundColor: cardBg, color: textColor, borderColor: borderColor, transition: 'all 0.3s' }}>
                            <Card.Body>
                                <Card.Title style={{ color: primaryColor }}>다크/라이트 모드</Card.Title>
                                <Card.Text style={{ color: dimTextColor }}>
                                    눈의 피로를 줄여주는 다크 모드와 기본 라이트 모드를 자유롭게 전환할 수 있습니다.
                                </Card.Text>
                            </Card.Body>
                        </Card>
                    </Col>

                    {/* 카드 3: 법률 특화 */}
                    <Col>
                        <Card style={{ backgroundColor: cardBg, color: textColor, borderColor: borderColor, transition: 'all 0.3s' }}>
                            <Card.Body>
                                <Card.Title style={{ color: primaryColor }}>민사법 특화</Card.Title>
                                <Card.Text style={{ color: dimTextColor }}>
                                LawFriend는 민사법에 최적화된 답변을 제공하는 인공지능 챗봇 서비스입니다.
                            </Card.Text>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
            </Container>
            
            {/* 3. CTA (Call to Action) 섹션: 챗봇 사용 유도 */}
            <Container 
                className="text-center py-4 px-5" 
                style={{
                    // mt-5 대신 변수 적용
                    paddingTop: sectionSpacing,
                    marginTop: sectionSpacing,
                    backgroundColor: primaryColor,
                    color: '#ffffff',
                    borderRadius: '15px',
                    boxShadow: '0 4px 6px rgba(0,0,0,0.1)',
            }}>
                <h3 className="mb-3 fw-bold">지금 바로 챗봇을 경험해보세요!</h3>
                <p className="mb-0">상단 내비게이션 바의 **'챗봇'** 메뉴를 클릭하여 대화를 시작할 수 있습니다.</p>
            </Container>

        </div>
    );
};

export default Home;