import React, { createContext, useState, useContext, useEffect } from "react";
import { HashRouter as Router, Routes, Route } from "react-router-dom"; 
// 다른 컴포넌트 파일들을 import 합니다.
import NavbarComp from "./components/Navbar";
import Footer from "./components/Footer";
import ScrollToTopButton from "./components/ScrollToTopButton";
import Home from "./pages/Home";
import ChatbotPage from "./pages/Chatbot";
import About from "./pages/About";


// --- Theme Context 및 Provider ---
export const ThemeContext = createContext({
    theme: 'light',
    toggleTheme: () => {},
});

export const ThemeProvider = ({ children }) => {
    // 로컬 스토리지에서 저장된 테마를 불러오거나 기본값 'light' 설정
    const [theme, setTheme] = useState(
        localStorage.getItem('theme') || 'light'
    );

    const toggleTheme = () => {
        setTheme(currentTheme => {
            const newTheme = currentTheme === 'light' ? 'dark' : 'light';
            localStorage.setItem('theme', newTheme);
            return newTheme;
        });
    };
    
    // ⭐️ 핵심 수정: 테마가 변경될 때마다 body에 'dark-mode' 클래스를 토글합니다.
    useEffect(() => {
        if (theme === 'dark') {
            document.body.classList.add('dark-mode');
        } else {
            document.body.classList.remove('dark-mode');
        }
    }, [theme]);

    return (
        <ThemeContext.Provider value={{ theme, toggleTheme }}>
            {children}
        </ThemeContext.Provider>
    );
};

export const useTheme = () => {
    return useContext(ThemeContext);
};
// --- Theme Context End ---


function App() {
    return (
        <ThemeProvider>
            <Router>
                <div className="d-flex flex-column min-vh-100">
                    <NavbarComp />
                    {/* ChatbotPage는 내부에서 Sidebar와 메인 컨텐츠를 관리하므로, flex-grow-1만 유지합니다. */}
                    <main className="flex-grow-1"> 
                        <Routes>
                            <Route path="/" element={<Home />} />
                            <Route path="/chat" element={<ChatbotPage />} />
                            <Route path="/about" element={<About />} />
                        </Routes>
                    </main>
                    <ScrollToTopButton />
                    <Footer />
                </div>
            </Router>
        </ThemeProvider>
    );
}

export default App;