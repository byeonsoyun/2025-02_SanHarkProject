import React, { useState, useEffect } from "react";
// 아이콘 대신 인라인 SVG를 사용하여 외부 라이브러리 종속성 제거 (FaArrowUp 대체)
const ArrowUpIcon = ({ size = 20, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <line x1="12" y1="19" x2="12" y2="5"></line>
        <polyline points="5 12 12 5 19 12"></polyline>
    </svg>
);


const ScrollToTopButton = () => {
    const [visible, setVisible] = useState(false);

    // 스크롤 이벤트 리스너 설정
    useEffect(() => {
        const handleScroll = () => {
            const scrolled = document.documentElement.scrollTop;
            setVisible(scrolled > 10); 
        };

        window.addEventListener("scroll", handleScroll);
        // 클린업 함수: 컴포넌트 언마운트 시 리스너 제거
        return () => window.removeEventListener("scroll", handleScroll);
    }, []);

    // 페이지 상단으로 부드럽게 스크롤
    const scrollToTop = () => {
        window.scrollTo({ top: 0, behavior: "smooth" });
    };

    // ⭐️ 스타일링: CSS 변수 적용 및 테마 호환성 확보
    const buttonStyle = {
        position: "fixed",
        bottom: "40px",
        right: "40px",
        // ⭐️ 테마의 강조 색상(primary-color) 사용
        backgroundColor: 'var(--primary-color)',
        color: "white",
        border: "none",
        borderRadius: "50%",
        width: "48px",
        height: "48px",
        display: visible ? "flex" : "none", // flex로 변경하여 아이콘 중앙 정렬
        alignItems: 'center',
        justifyContent: 'center',
        cursor: "pointer",
        boxShadow: "0px 4px 8px rgba(0,0,0,0.2)",
        zIndex: 9999,
        transition: "background-color 0.3s, opacity 0.3s ease-in-out",
        opacity: visible ? 1 : 0,
        // 터치 장치에서 더 잘 작동하도록 크기 조정
    };

    return (
        <button
            onClick={scrollToTop}
            style={buttonStyle}
            aria-label="Scroll to top"
        >
            <ArrowUpIcon size={24} color="#ffffff" />
        </button>
    );
};

export default ScrollToTopButton;
