import React from "react";

const Footer = () => (
    <div style={{
        padding: '15px',
        textAlign: 'center',
        borderTop: '1px solid var(--border-color)',
        backgroundColor: 'var(--bg-card)',
        color: 'var(--dim-text-color)',
        fontSize: '0.8em',
        flexShrink: 0,
        transition: 'background-color 0.3s, border-color 0.3s, color 0.3s'
    }}>
        © 2025 My Chatbot. All rights reserved.
    </div>
);

export default Footer;
