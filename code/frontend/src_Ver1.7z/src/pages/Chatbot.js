import React, { useState, useEffect, useRef, useCallback } from "react";
import { useTheme } from "../App";
import Sidebar from "../components/Sidebar"; // ⭐️ Sidebar 컴포넌트 import

// 인라인 SVG 아이콘 (SendIcon, UploadIcon, ClearIcon)
const SendIcon = ({ size = 20, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <line x1="22" y1="2" x2="11" y2="13"></line>
        <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
    </svg>
);

const UploadIcon = ({ size = 20, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
        <polyline points="17 8 12 3 7 8"></polyline>
        <line x1="12" y1="3" x2="12" y2="15"></line>
    </svg>
);

const XIcon = ({ size = 20, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <line x1="18" y1="6" x2="6" y2="18"></line>
        <line x1="6" y1="6" x2="18" y2="18"></line>
    </svg>
);


const ChatbotPage = () => {
    const { theme } = useTheme();
    const messagesEndRef = useRef(null);
    
    // ⭐️ 챗봇 로직 상태: 멀티 세션 관리를 위해 chats 배열을 사용합니다.
    const [chats, setChats] = useState([
        { 
            id: 1, 
            name: "New Chatting", 
            messages: [
                { sender: 'gemini', text: "안녕하세요! 질문을 입력하거나 PDF 파일을 업로드해 주세요.", id: 1 }
            ]
        }
    ]);
    const [currentChatId, setCurrentChatId] = useState(1);
    const [inputText, setInputText] = useState("");
    const [pdfFile, setPdfFile] = useState(null);
    const [loading, setLoading] = useState(false);

    // 현재 활성화된 채팅 세션에서 메시지 목록을 가져옵니다.
    const currentChat = chats.find(c => c.id === currentChatId);
    const messages = currentChat?.messages || [];

    // --- 사이드바 로직 ---
    
    // 1. 새 채팅 생성: New Chatting, New Chatting(1), ... 순서로 이름을 자동 생성합니다.
    const handleCreateNewChat = useCallback(() => {
        const chatNames = chats.map(c => c.name);
        let newChatName = "New Chatting";
        let index = 0;

        // 중복되지 않는 이름 찾기
        while (chatNames.includes(newChatName)) {
            index++;
            newChatName = `New Chatting(${index})`;
        }

        const newChat = {
            id: Date.now(),
            name: newChatName,
            messages: [
                { sender: 'gemini', text: "새로운 채팅 세션입니다. 질문을 시작하세요.", id: Date.now() + 1 }
            ]
        };

        setChats(prev => [newChat, ...prev]);
        setCurrentChatId(newChat.id); // 새 채팅 활성화
        setInputText(""); // 입력창 초기화
        setPdfFile(null); // PDF 파일 초기화
        scrollToBottom(); // 스크롤
    }, [chats]);
    
    // 2. 채팅 선택
    const handleSelectChat = useCallback((id) => {
        setCurrentChatId(id);
        setInputText("");
        setPdfFile(null);
        // 선택 시에도 스크롤을 맨 아래로 이동
        scrollToBottom(); 
    }, []);

    // 3. 채팅 이름 수정
    const handleUpdateChatName = useCallback((id, newName) => {
        setChats(prev => prev.map(chat => 
            chat.id === id ? { ...chat, name: newName } : chat
        ));
    }, []);


    // --- 채팅 로직 ---

    // 스크롤을 맨 아래로 이동
    const scrollToBottom = useCallback(() => {
        setTimeout(() => {
            messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
        }, 0);
    }, []);

    // 챗 상태를 변경하는 헬퍼 함수
    const updateMessages = useCallback((message) => {
        setChats(prev => prev.map(chat => 
            chat.id === currentChatId 
                ? { ...chat, messages: [...chat.messages, message] } 
                : chat
        ));
        scrollToBottom(); // 메시지 추가 후 스크롤
    }, [currentChatId, scrollToBottom]);

    // 텍스트/PDF 전송 로직
    const handleSubmit = async (e) => {
        if(e) e.preventDefault(); 
        if (!inputText.trim() && !pdfFile || loading) return;

        setLoading(true);

        try {
            let replyText = "";
            let userMessage = "";
            
            // 1. PDF 업로드 전송
            if (pdfFile) {
                userMessage = `[PDF 업로드] ${pdfFile.name}`;
                updateMessages({ sender: "user", text: userMessage, id: Date.now() });

                const formData = new FormData();
                formData.append("pdf", pdfFile);

                // ⭐️ API 호출 시뮬레이션: PDF
                const response = await fetch("/chat/upload_pdf/", { method: "POST", body: formData });
                const data = await response.json();
                replyText = data.reply;
                setPdfFile(null);
            }

            // 2. 텍스트 메시지 전송
            if (inputText.trim()) {
                userMessage = inputText.trim();
                updateMessages({ sender: "user", text: userMessage, id: Date.now() });
                setInputText("");

                // ⭐️ API 호출 시뮬레이션: 텍스트
                const response = await fetch("/chat/api/chat/", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ message: userMessage }),
                });
                const data = await response.json();
                replyText = data.reply;
            }

            // 3. 봇 응답 추가
            if (replyText) {
                const botMessage = { sender: "gemini", text: replyText, id: Date.now() + 1 };
                updateMessages(botMessage);
            }
            
        } catch (err) {
            console.error("API Error:", err);
            updateMessages({ sender: "gemini", text: "죄송합니다. API 호출 중 오류가 발생했습니다.", id: Date.now() + 1 });
        } finally {
            setLoading(false);
        }
    };

    // 엔터로 텍스트 전송
    const handleKeyPress = e => {
        if (e.key === "Enter" && !loading) {
            e.preventDefault();
            handleSubmit();
        }
    };


    const MessageBubble = ({ message }) => {
        const isUser = message.sender === 'user';
        return (
            <div style={{
                display: 'flex',
                justifyContent: isUser ? 'flex-end' : 'flex-start',
                marginBottom: '10px',
                padding: '0 20px',
            }}>
                <div style={{
                    maxWidth: '80%',
                    padding: '12px 16px',
                    borderRadius: '20px',
                    borderBottomLeftRadius: isUser ? '20px' : '2px',
                    borderBottomRightRadius: isUser ? '2px' : '20px',
                    backgroundColor: isUser ? 'var(--primary-color)' : 'var(--color-card-bg)', 
                    color: isUser ? '#ffffff' : 'var(--color-text)', 
                    boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
                    lineHeight: 1.5,
                    fontSize: '0.95em',
                    transition: 'background-color 0.3s, color 0.3s'
                }}>
                    {message.text}
                </div>
            </div>
        );
    };

    return (
        // ⭐️ FIX: 전체 레이아웃을 flex로 변경하고 Sidebar와 Main Content를 나란히 배치
        <div style={{ 
            display: 'flex', 
            height: 'calc(100vh - 56px)', // Footer가 붙어있지 않도록 높이 설정
            width: '100%', 
            overflow: 'hidden' // 스크롤이 바깥으로 나가지 않도록
        }}>
            
            {/* 1. 사이드바 컴포넌트 */}
            <Sidebar
                chats={chats}
                currentChatId={currentChatId}
                onCreateNewChat={handleCreateNewChat}
                onSelectChat={handleSelectChat}
                onUpdateChatName={handleUpdateChatName}
            />

            {/* 2. 메인 채팅 영역 (최대 너비 적용 및 중앙 정렬) */}
            <div style={{ 
                display: 'flex', 
                flexDirection: 'column', 
                flexGrow: 1, 
                maxWidth: '800px', // 기존 채팅 영역의 최대 너비
                margin: '0 auto', // 중앙 정렬
                width: '100%',
                height: '100%'
            }}>
                
                {/* 메시지 영역 */}
                <div style={{ flexGrow: 1, overflowY: 'auto', padding: '20px 0', backgroundColor: 'var(--color-background)' }}>
                    {messages.map((msg, index) => (
                        <MessageBubble key={msg.id || index} message={msg} />
                    ))}
                    
                    {/* 로딩 표시 (기존과 동일) */}
                    {loading && (
                        <div style={{ display: 'flex', justifyContent: 'flex-start', padding: '0 20px 10px' }}>
                             <div style={{
                                maxWidth: '80%',
                                padding: '12px 16px',
                                borderRadius: '20px',
                                borderBottomLeftRadius: '2px',
                                borderBottomRightRadius: '20px',
                                backgroundColor: 'var(--color-card-bg)',
                                color: 'var(--dim-text-color)',
                                boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
                                fontSize: '0.95em',
                                opacity: 0.7
                              }}>
                                {pdfFile ? `PDF 파일을 업로드하고 있습니다...` : `응답 생성 중...`}
                              </div>
                        </div>
                    )}
                    
                    <div ref={messagesEndRef} />
                </div>

                {/* 입력 폼 (기존과 동일) */}
                <form onSubmit={handleSubmit} style={{
                    padding: '10px 20px', 
                    borderTop: '1px solid var(--border-color)',
                    backgroundColor: 'var(--color-card-bg)',
                    display: 'flex',
                    gap: '10px',
                    flexShrink: 0,
                    flexDirection: 'column',
                }}>
                    
                    {/* 1. 입력 필드 및 버튼 영역 */}
                    <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                        
                        {/* PDF 선택 버튼 */}
                        <label htmlFor="pdf-upload" style={{
                             display: 'flex',
                             alignItems: 'center',
                             justifyContent: 'center',
                             cursor: loading ? 'default' : 'pointer',
                             width: '45px',
                             height: '45px',
                             borderRadius: '8px',
                             backgroundColor: pdfFile ? 'var(--primary-color)' : (loading ? 'var(--dim-text-color)' : 'var(--color-text)'),
                             color: '#ffffff',
                             flexShrink: 0,
                             transition: 'background-color 0.2s',
                             opacity: loading ? 0.5 : 1
                        }}>
                            <UploadIcon 
                                size={20} 
                                color={(theme === 'dark' && !pdfFile && !loading) ? 'var(--color-card-bg)' : '#ffffff'} 
                            />
                        </label>
                        <input
                            id="pdf-upload"
                            type="file"
                            accept="application/pdf"
                            style={{ display: "none" }}
                            onChange={(e) => {
                                const file = e.target.files[0];
                                if (file && file.type === "application/pdf") {
                                    setPdfFile(file);
                                } else {
                                    setPdfFile(null);
                                    console.error("PDF 파일만 업로드할 수 있습니다."); 
                                }
                            }}
                            disabled={loading}
                            key={pdfFile ? pdfFile.name : 'empty'}
                        />

                        {/* 입력 필드 */}
                        <input
                            type="text"
                            value={inputText}
                            onChange={(e) => setInputText(e.target.value)}
                            placeholder={loading ? "처리 중..." : (pdfFile ? `파일에 대한 질문을 입력하세요...` : "메시지를 입력하세요.")}
                            disabled={loading}
                            onKeyPress={handleKeyPress}
                            style={{
                                flexGrow: 1,
                                padding: '10px 15px',
                                borderRadius: '8px',
                                border: '1px solid var(--border-color)',
                                backgroundColor: 'var(--color-background)',
                                color: 'var(--color-text)',
                                fontSize: '1em',
                                outline: 'none',
                                transition: 'border-color 0.3s, background-color 0.3s',
                            }}
                        />
                        
                        {/* 전송 버튼 */}
                        <button
                            type="submit"
                            disabled={loading || (!inputText.trim() && !pdfFile)}
                            style={{
                                padding: '10px 15px',
                                borderRadius: '8px',
                                backgroundColor: (loading || (!inputText.trim() && !pdfFile)) ? 'var(--dim-text-color)' : 'var(--primary-color)',
                                color: '#ffffff',
                                border: 'none',
                                cursor: (loading || (!inputText.trim() && !pdfFile)) ? 'default' : 'pointer',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                transition: 'background-color 0.2s, transform 0.1s',
                                boxShadow: '0 2px 5px rgba(0,0,0,0.2)',
                                width: '45px',
                                height: '45px',
                            }}
                        >
                            <SendIcon size={20} color="#ffffff" />
                        </button>
                    </div>
                    
                    {/* 2. 선택된 PDF 표시 및 제거 버튼 */}
                    {pdfFile && (
                        <div style={{ 
                            marginTop: '5px', 
                            padding: '8px 15px',
                            borderRadius: '15px',
                            backgroundColor: 'var(--color-background)',
                            color: 'var(--color-text)',
                            border: '1px solid var(--border-color)',
                            display: 'flex',
                            justifyContent: 'space-between',
                            alignItems: 'center',
                            fontSize: '0.9em'
                        }}>
                            <span style={{color: 'var(--color-text)'}}>선택된 PDF: **{pdfFile.name}**</span>
                            <button
                                type="button"
                                onClick={() => setPdfFile(null)}
                                disabled={loading}
                                style={{
                                    background: 'none',
                                    border: 'none',
                                    color: 'var(--dim-text-color)',
                                    cursor: 'pointer',
                                    padding: '0 5px',
                                    opacity: loading ? 0.5 : 1
                                }}
                                aria-label="Remove selected PDF"
                            >
                                <XIcon size={16} />
                            </button>
                        </div>
                    )}
                </form>
            </div>
        </div>
    );
};

export default ChatbotPage;