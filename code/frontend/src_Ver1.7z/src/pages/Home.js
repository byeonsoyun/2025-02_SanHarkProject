import React from "react";
import { Link } from "react-router-dom";
// react-bootstrap 컴포넌트 import
import { Container, Button } from "react-bootstrap";

const Home = () => {
    // 테마 변수 사용을 위한 CSS 변수 정의
    const primaryTextColor = 'var(--color-text)';
    const dimTextColor = 'var(--dim-text-color)';

    return (
        <Container className="text-center mt-5">
            {/* h1 태그에 주요 텍스트 색상 및 전환 효과 적용 */}
            <h1 className="mb-3" style={{ color: primaryTextColor, transition: 'color 0.3s' }}>
                홈 페이지
            </h1>
            {/* p 태그에 옅은 텍스트 색상 및 전환 효과 적용 */}
            <p className="lead mb-4" style={{ color: dimTextColor, transition: 'color 0.3s' }}>
                이곳은 챗봇 서비스 테스트 홈페이지입니다.
            </p>
            <Link to="/chat">
                {/* Bootstrap primary 버튼 */}
                <Button variant="primary" className="me-3">챗봇 페이지로 이동</Button>
            </Link>
            <Link to="/about">
                {/* Bootstrap success 버튼 */}
                <Button variant="success">About Us</Button>
            </Link>
        </Container>
    );
};

export default Home;