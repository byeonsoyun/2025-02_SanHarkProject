import React from "react";
import { Container } from "react-bootstrap";

const About = () => {
    // 테마 변수 정의
    const primaryColor = 'var(--primary-color)';
    const primaryTextColor = 'var(--color-text)';
    const borderColor = 'var(--border-color)';

    // 테마 적용된 구분선 스타일
    const themedHrStyle = {
        border: 'none',
        borderTop: `1px solid ${borderColor}`,
        margin: '1.5rem 0', // 여백 추가
        transition: 'border-color 0.3s',
    };
    
    // 테마 적용된 본문 텍스트 스타일
    const themedTextStyle = {
        color: primaryTextColor, 
        transition: 'color 0.3s',
        lineHeight: 1.6
    };

    // 테마 적용된 제목 스타일 (강조 색상 사용)
    const themedHeadingStyle = {
        color: primaryColor, 
        transition: 'color 0.3s',
        marginBottom: '0.75rem' // 제목 아래 여백
    };

    return (
        <Container className="mt-5" style={{ paddingBottom: '50px' }}>
            {/* H2 - 강조 색상 적용 */}
            <h2 style={themedHeadingStyle}>About Us</h2>
            
            {/* 첫 번째 문단 */}
            <p style={themedTextStyle}>
                BYB 입니다. 인공지능 챗봇 기반 서비스를 제공합니다.
            </p>
            
            {/* 테마 적용된 구분선 */}
            <hr style={themedHrStyle} /> 
            
            {/* H3 - 강조 색상 적용 */}
            <h3 style={themedHeadingStyle}>Server Programming</h3>
            
            {/* 두 번째 문단 */}
            <p style={themedTextStyle}>
                Course Description: This course aims to provide students with a comprehensive understanding of server programming, from basic concepts to practical skills applicable in real-world scenarios. This course covers various topics related to the design and implementation of server programs based on Linux systems and the C programming language, and includes hands-on practice through actual projects.
            </p>
        </Container>
    );
};

export default About;