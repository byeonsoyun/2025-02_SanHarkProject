import React from "react";
import { Link, useLocation } from "react-router-dom";
import { useTheme } from "../App"; // App.js에서 정의한 Context Hook import

// 인라인 SVG 아이콘 (lucide-react 대체)
const MoonIcon = ({ size = 20 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
    </svg>
);

const SunIcon = ({ size = 20 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="5"></circle>
        <line x1="12" y1="1" x2="12" y2="3"></line>
        <line x1="12" y1="21" x2="12" y2="23"></line>
        <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
        <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
        <line x1="1" y1="12" x2="3" y2="12"></line>
        <line x1="21" y1="12" x2="23" y2="12"></line>
        <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
        <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
    </svg>
);


const NavbarComp = () => {
    const location = useLocation();
    const { theme, toggleTheme } = useTheme();

  const textColor = 'var(--color-text)';
  const navBgColor = 'var(--color-navbar-bg)'; 


    const navItemStyle = (path) => ({
        color: textColor,
        padding: '0 15px',
        textDecoration: 'none',
        fontWeight: location.pathname === path ? 'bold' : 'normal',
        opacity: 0.8,
        transition: 'opacity 0.2s, color 0.3s', // 색상 전환 추가
        cursor: 'pointer',
    });
    
    return (
        <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            padding: '10px 20px',
            backgroundColor: navBgColor,
            boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
            transition: 'background-color 0.3s',
            position: 'sticky',
            top: 0,
            zIndex: 10,
            minHeight: '56px',
            flexShrink: 0
        }}>
            <Link to="/" style={{ color: textColor, fontSize: '1.5em', textDecoration: 'none', transition: 'color 0.3s' }}>
                My Chatbot
            </Link>
            
            <nav style={{ display: 'flex', alignItems: 'center' }}>
                <Link to="/" style={navItemStyle("/")}>홈</Link>
                <Link to="/chat" style={navItemStyle("/chat")}>챗봇</Link>
                <Link to="/about" style={navItemStyle("/about")}>About</Link>
                
                <button
                    onClick={toggleTheme}
                    style={{
                        background: 'none',
                        border: 'none',
                        cursor: 'pointer',
                        color: textColor,
                        padding: '5px 15px',
                        marginLeft: '15px',
                        transition: 'color 0.3s' // 색상 전환 추가
                    }}
                    aria-label="Toggle dark mode"
                >
                    {theme === 'light' ? <MoonIcon size={20} /> : <SunIcon size={20} />}
                </button>
            </nav>
        </div>
    );
};

export default NavbarComp;