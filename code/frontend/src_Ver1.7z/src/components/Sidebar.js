import React, { useState } from 'react';
import { useTheme } from '../App';

// 인라인 SVG 아이콘 (Gemini Look-alike)
const MenuIcon = ({ size = 20, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <line x1="3" y1="12" x2="21" y2="12"></line>
        <line x1="3" y1="6" x2="21" y2="6"></line>
        <line x1="3" y1="18" x2="21" y2="18"></line>
    </svg>
);
const EditIcon = ({ size = 16, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path>
    </svg>
);
const ChatIcon = ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
    </svg>
);
const PlusIcon = ({ size = 18, color = 'currentColor' }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <line x1="12" y1="5" x2="12" y2="19"></line>
        <line x1="5" y1="12" x2="19" y2="12"></line>
    </svg>
);


const Sidebar = ({ chats, currentChatId, onCreateNewChat, onSelectChat, onUpdateChatName }) => {
    const { theme } = useTheme();
    const [isExpanded, setIsExpanded] = useState(true);
    const [editingId, setEditingId] = useState(null);
    const [editName, setEditName] = useState('');

    const sidebarBg = 'var(--color-card-bg)';
    const textColor = 'var(--color-text)';
    const primaryColor = 'var(--primary-color)';
    const dimColor = 'var(--dim-text-color)';
    const transitionDuration = '0.3s';
    
    // 채팅 이름 편집 시작 핸들러
    const handleEditStart = (chat) => {
        setEditingId(chat.id);
        setEditName(chat.name);
    };

    // 채팅 이름 저장 핸들러
    const handleEditSave = (id) => {
        if (editName.trim() && editName !== chats.find(c => c.id === id)?.name) {
            onUpdateChatName(id, editName.trim());
        }
        setEditingId(null);
    };

    // 엔터 키 입력 시 저장
    const handleKeyPress = (e, id) => {
        if (e.key === 'Enter') {
            handleEditSave(id);
        }
    };

    // 채팅 목록 렌더링
    const renderChatList = () => (
        <div style={{ padding: isExpanded ? '0 15px' : '0', overflowY: 'auto', flexGrow: 1 }}>
            {/* id를 내림차순으로 정렬하여 최신 채팅이 위에 오도록 합니다. */}
            {chats.sort((a, b) => b.id - a.id).map(chat => {
                const isActive = chat.id === currentChatId;
                const isEditing = chat.id === editingId;

                return (
                    <div
                        key={chat.id}
                        style={{
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                            padding: isExpanded ? '10px 10px' : '10px 8px',
                            margin: '8px 0',
                            borderRadius: '20px',
                            backgroundColor: isActive ? primaryColor : 'transparent',
                            color: isActive ? 'white' : textColor,
                            cursor: 'pointer',
                            fontSize: '0.9em',
                            transition: 'background-color 0.2s, color 0.2s, padding 0.2s',
                            whiteSpace: 'nowrap',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                        }}
                        onClick={() => !isEditing && onSelectChat(chat.id)}
                        title={chat.name}
                    >
                        {isExpanded ? (
                            isEditing ? (
                                <input
                                    type="text"
                                    value={editName}
                                    onChange={(e) => setEditName(e.target.value)}
                                    onBlur={() => handleEditSave(chat.id)}
                                    onKeyPress={(e) => handleKeyPress(e, chat.id)}
                                    style={{
                                        background: 'transparent',
                                        border: 'none',
                                        color: isActive ? 'white' : textColor,
                                        width: '85%',
                                        outline: 'none',
                                        fontSize: '1em',
                                    }}
                                    autoFocus
                                />
                            ) : (
                                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', minWidth: 0 }}>
                                    <ChatIcon size={18} color={isActive ? 'white' : dimColor} />
                                    <span style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>
                                        {chat.name}
                                    </span>
                                </div>
                            )
                        ) : (
                            <ChatIcon size={18} color={isActive ? 'white' : dimColor} />
                        )}

                        {isExpanded && !isEditing && (
                            <button
                                style={{
                                    background: 'none',
                                    border: 'none',
                                    color: isActive ? 'white' : dimColor,
                                    cursor: 'pointer',
                                    padding: '0',
                                    display: 'flex',
                                    alignItems: 'center',
                                    transition: 'color 0.2s',
                                }}
                                onClick={(e) => {
                                    e.stopPropagation(); // 부모 div의 onSelectChat 방지
                                    handleEditStart(chat);
                                }}
                                title="이름 수정"
                            >
                                <EditIcon size={14} color={isActive ? 'white' : dimColor} />
                            </button>
                        )}
                    </div>
                );
            })}
        </div>
    );

    return (
        <div style={{
            display: 'flex',
            flexDirection: 'column',
            width: isExpanded ? '250px' : '70px',
            minWidth: isExpanded ? '250px' : '70px',
            height: '100%',
            backgroundColor: sidebarBg,
            borderRight: '1px solid var(--border-color)',
            transition: `width ${transitionDuration}, min-width ${transitionDuration}, background-color ${transitionDuration}`,
            flexShrink: 0,
        }}>
            
            {/* 1. 상단 메뉴 및 New Chat 버튼 */}
            <div style={{ padding: '15px', display: 'flex', flexDirection: 'column', gap: '15px', flexShrink: 0 }}>
                {/* 햄버거 메뉴 아이콘 */}
                <button
                    onClick={() => setIsExpanded(!isExpanded)}
                    style={{
                        background: 'none',
                        border: 'none',
                        padding: '5px',
                        cursor: 'pointer',
                        color: textColor,
                        alignSelf: 'flex-start',
                        transition: 'color 0.3s',
                    }}
                >
                    <MenuIcon size={24} color={textColor} />
                </button>

                {/* New Chat 버튼 (Gemini 스타일) */}
                {isExpanded && (
                    <button
                        onClick={onCreateNewChat}
                        style={{
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            gap: '8px',
                            padding: '10px 15px',
                            borderRadius: '25px',
                            backgroundColor: 'var(--color-background)',
                            color: textColor,
                            border: `1px solid ${dimColor}`,
                            cursor: 'pointer',
                            fontSize: '1em',
                            transition: 'background-color 0.2s, border-color 0.2s',
                        }}
                    >
                        <PlusIcon size={18} color={textColor} />
                        New Chat
                    </button>
                )}
            </div>

            {/* 2. 채팅 목록 영역 */}
            {isExpanded && (
                <div style={{ 
                    padding: '0 15px 15px', 
                    color: dimColor, 
                    fontSize: '0.85em', 
                    fontWeight: 'bold', 
                    flexShrink: 0 
                }}>
                    채팅 목록
                </div>
            )}
            
            {renderChatList()}

            {/* 3. 하단 설정 영역 (선택 사항: 나중에 추가 가능) */}
            <div style={{ height: '30px', flexShrink: 0 }}>
                {/* 하단 여백 또는 설정/사용자 정보 공간 */}
            </div>
        </div>
    );
};

export default Sidebar;